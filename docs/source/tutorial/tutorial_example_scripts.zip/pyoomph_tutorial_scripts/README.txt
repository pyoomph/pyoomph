Here, you find the python scripts used and explained throughout the tutorial of pyoomph.
You can find pyoomph here: TODO
The tutorial is hosted here: TODO
