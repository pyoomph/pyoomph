Here, you find the python scripts used and explained throughout the tutorial of pyoomph.
You can find pyoomph here: https://github.com/pyoomph/pyoomph
The tutorial is hosted here: https://pyoomph.readthedocs.io
