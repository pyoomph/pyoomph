import warnings

warnings.filterwarnings("error")

import matplotlib.pyplot as plt
import numpy ,glob

ax = plt.figure().add_subplot(projection='3d')
import mpl_toolkits.mplot3d.art3d as art3d


chaos=numpy.loadtxt("langford.txt")

# Create the 3D-line collection object

minrho=1.6
maxrho=2.1
cmap=plt.get_cmap('seismic')
norm=plt.Normalize(minrho, maxrho)
def colline(data,stable,rho_override=None):    
    rho,x,y,z=data[:,0],data[:,1],data[:,2],-data[:,3]
    points = numpy.array([x, y, z]).T.reshape(-1, 1, 3)
    if rho_override is None:
        segments = numpy.concatenate([points[:-1], points[1:]], axis=1)
        lc = art3d.Line3DCollection(segments, cmap=cmap,norm=norm)    
        lc.set_array(rho) 
        if stable:
            lc.set_linewidth(2)
        else:
            lc.set_linewidth(0.5)
        ax.add_collection3d(lc, zs=z, zdir='z')
    else:
        ax.plot(x,y,zs=z,zdir='z',color=cmap(norm(rho_override)),linewidth=2 if stable else 0.5)
    
    
for i in range(1000,1001):        
    ax=plt.figure().add_subplot(projection='3d')        
    survided_loop=True
    numorbits=0
    floqdata=None
    for dn in (sorted(glob.glob("orbit_*"))[1:]):
        rho=float(dn.split("_")[-1])
        #print(i,dn,rho)

        data=numpy.loadtxt(dn+"/langford.txt")    
        colline(data,stable=False,rho_override=rho)
        numorbits+=1
        if numorbits>50:
            break
        
        
    j=i
    k=min(10*j,len(chaos))
    ax.plot(chaos[:k,1],chaos[:k,2],zs=-chaos[:k,3],zdir="z",color="black",linewidth=0.5)
    ax.scatter(chaos[k-1,1],chaos[k-1,2],zs=-chaos[k-1,3],zdir="z",color="black",s=10)                    



    ax.set_xlim(-1, 1)
    ax.set_ylim(-1, 1)
    ax.set_zlim(-1.5, -0.7)
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('-z')



    plt.tight_layout()
    #äplt.show()
    plt.savefig("plots_tint/plot_{:04d}.svg".format(i))
    plt.close()


exit()
if floqdata is not None:
    ax2=plt.figure().add_subplot()
    set_size(3,3,ax2)
    print(floqdata)
    ax2.scatter(floqdata[:,0],floqdata[:,1])
    ax2.set_xlabel(r"$\mathrm{Re}(\lambda)$")
    ax2.set_ylabel(r"$\mathrm{Im}(\lambda)$")
    ax2.set_title("Floquet multipliers")
    ax2.grid()
